# -*- coding: utf-8 -*-
# This file makes the directory a Python package

from .processor import process_image