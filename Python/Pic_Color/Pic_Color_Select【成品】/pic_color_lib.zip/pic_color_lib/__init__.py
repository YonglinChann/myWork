# pic_color_lib 包初始化文件

from .pic_processor import PicProcessor

__version__ = '1.0.0'
__all__ = ['PicProcessor']